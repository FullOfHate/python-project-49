import prompt
import random


def even():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print('Hello, ' + name)
    question = random.randint(0, 100)
    print('Answer "yes" if the number is even, otherwise answer "no".')
    print('Question: ' + question)
    answer = prompt.string('Your answer: ')
    print('Your answer: ' + answer)
    if answer == 'yes':
        if question % 2 == 0:
            print('Correct!')
        else:
            print(f"'yes' is wrong answer ;(. Correct answer was 'no'. \n Let's try again, {name}")
    if answer == 'no':
        if question % 2 != 0:
            print('Correct!')
        else:
            print(f"'no' is wrong answer ;(. Correct answer was 'yes'. \n Let's try again, {name}")
