#!/usr/bin/env python3

from brain_games.even import even


def main():
    even()


if __name__ == '__main__':
    main()
