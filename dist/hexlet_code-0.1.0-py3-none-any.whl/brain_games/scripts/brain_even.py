#!/usr/bin/env python3

from brain_games.games.even import even
from brain_games.greet import greeting


def main():
    even()


if __name__ == '__main__':
    main()
