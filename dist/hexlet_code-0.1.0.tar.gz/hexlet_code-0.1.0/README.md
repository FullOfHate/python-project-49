### Hexlet tests and linter status:
[![Actions Status](https://github.com/FullOfHate/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/FullOfHate/python-project-49/actions)

### install and run BRAIN_EVEN
https://asciinema.org/a/SsCfIpET6UoPx5XPOgRKdTZ8Z

### install and run BRAIN_CALC
https://asciinema.org/a/epGwbIVOTd1YajN89Avfh0JKg