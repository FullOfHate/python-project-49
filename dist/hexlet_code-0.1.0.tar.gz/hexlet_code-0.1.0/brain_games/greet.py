def greeting():
    print('Welcome to the Brain Games!')
