#!/usr/bin/env python3

from brain_games.scripts.greet import greeting

def main():
    greeting()

if __name__ == '__main__':
    main()



