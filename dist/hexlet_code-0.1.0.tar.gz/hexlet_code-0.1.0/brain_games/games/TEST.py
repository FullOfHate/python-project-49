a = 'asdas'
b = str
print(isinstance(a, int))